import React from 'react';
import 'assets/scss/App.scss';

class AboutPage extends React.PureComponent {
  render() {
    return (
      <div>
        <h1>About</h1>
        <p>Another page to showcase routing (react-dom-router).</p>
      </div>
    );
  }
}

export default AboutPage;
